import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/place.dart';

class PlaceService {
  static Future<List<Place>> getAllPlaces() async {
    final response = await http.get(Uri.parse('http://10.0.2.2:8080/api/places/getAllPlace')); // dùng 10.0.2.2 nếu chạy Flutter Android Emulator

    if (response.statusCode == 200) {
      List<dynamic> data = jsonDecode(response.body);
      return data.map((item) => Place.fromJson(item)).toList();
    } else {
      throw Exception('Failed to load places');
    }
  }
}