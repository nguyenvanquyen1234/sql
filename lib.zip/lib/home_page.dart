import 'package:flutter/material.dart';
import 'models/place.dart';
import 'services/place_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Place> places = [];

  @override
  void initState() {
    super.initState();
    loadPlaces();
  }

  void loadPlaces() async {
    final result = await PlaceService.getAllPlaces();
    setState(() {
      places = result;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Popular Destinations")),
      body: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: places.length,
        itemBuilder: (context, index) {
          final place = places[index];
          return Card(
            child: Column(
              children: [
                Image.network(place.imageUrl, width: 200, height: 120, fit: BoxFit.cover),
                Text(place.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(place.description),
              ],
            ),
          );
        },
      ),
    );
  }
}